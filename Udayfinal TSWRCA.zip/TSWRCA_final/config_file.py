from mongoengine import connect

client = connect('classbank',host='localhost',port=27017)